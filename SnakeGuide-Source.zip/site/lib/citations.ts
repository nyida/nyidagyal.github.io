import {Article,sources} from './content';
import metadata from './paper-metadata.json';
type PaperMeta={authorsBibtex:string;venue:string;year:number;type:string;doi?:string;arxiv?:string;volume?:string;number?:string;pages?:string;publisher?:string;sourceUrls:string[]};
export const paperMetadata:Record<string,PaperMeta>=metadata;
export function noteCitation(a:Article){return `@misc{snakeguide2026${a.slug.replaceAll('-','')},\n  author = {{SnakeGuide}},\n  title = {${a.title}},\n  year = {2026},\n  note = {Technical note; explanatory synthesis},\n  url = {https://snakeguide.org/articles/${a.slug}}\n}`}
export function sourceCitation(s:typeof sources[number]){
 const m=paperMetadata[s.id];const fields:Record<string,string>={author:m?.authorsBibtex||`{${s.authors}}`,title:s.title};
 if(m){fields.year=String(m.year);if(m.type==='article')fields.journal=m.venue;else if(m.type==='inproceedings')fields.booktitle=m.venue;else fields.note=m.venue;
 for(const k of ['volume','number','pages','publisher','doi'] as const)if(m[k])fields[k]=m[k]!;
 if(m.arxiv){fields.eprint=m.arxiv;fields.archivePrefix='arXiv'}}else {if(s.year)fields.year=String(s.year);fields.howpublished=s.type}
 fields.url=s.url;return `@${m?.type||'misc'}{${s.id.replaceAll('-','')},\n${Object.entries(fields).map(([k,v])=>`  ${k} = {${v}}`).join(',\n')}\n}`;
}
