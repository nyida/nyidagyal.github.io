import core from './core-articles.json';
import research from './research-articles.json';
import bibliography from './sources.json';
export type Article={slug:string;title:string;category:string;level:string;description:string;abstract:string;diagram:string;minutes:number;sections:{heading:string;paragraphs:string[];formula?:string;code?:string}[];takeaway:string;sources:string[]};
export const articles=([...core,...research] as Article[]).map(a=>({...a,minutes:Math.ceil(wordCount(a)/180)+2}));
export const sources=bibliography;
export const categories=['All articles','Foundations','Algorithms','Research','Engineering'];
export const getArticle=(slug:string)=>articles.find(a=>a.slug===slug);
export const anchor=(s:string)=>s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/-$/,'');
export function wordCount(a:Article){return a.sections.reduce((n,s)=>n+s.paragraphs.join(' ').split(/\s+/).length,0)}
