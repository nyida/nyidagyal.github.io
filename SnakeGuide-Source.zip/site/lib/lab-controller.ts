import {Cell,Game,cycle,foodFor,key} from './engine';

/** Start on the route's ordering; arbitrary bodies do not inherit its guarantee. */
export function cycleGame(seed:number):Game {
 const route=cycle(12,10),body=[route[5],route[4],route[3]];
 return {body,...foodFor(body,12,10,seed),dir:{x:1,y:0},steps:0,score:0,status:'playing'};
}

export function cycleAction(game:Game,route:Cell[],indices:Map<string,number>):Cell {
 const i=indices.get(key(game.body[0]));
 if(i===undefined)throw new Error('The head must lie on the cycle.');
 const next=route[(i+1)%route.length];
 return {x:next.x-game.body[0].x,y:next.y-game.body[0].y};
}
