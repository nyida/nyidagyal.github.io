export type ScientificPlateKind = 'state' | 'search' | 'cycle' | 'connectivity' | 'reward' | 'evaluation';

export const scientificPlates: Record<ScientificPlateKind, {file: string; title: string; caption: string; alt: string; height: number; evidence: string}> = {
  state: {
    file: 'state-order', title: 'Ordered body and state transitions', height: 565, evidence: 'Exact engine states',
    caption: 'Three engine states distinguish occupied cells from body order. Entering the vacating tail keeps length four; eating retains the tail and increases length to five. The successors use different inputs, as specified in the figure.',
    alt: 'Three annotated coordinate grids show the same four-segment snake before a move, after legal tail entry, and after eating and growing. Segment indices identify head and tail.',
  },
  search: {
    file: 'search-landscape', title: 'Weighted path cost and search effort', height: 610, evidence: 'Computed search traces',
    caption: 'BFS, Dijkstra, and A* search the same weighted board at seed 2031. BFS returns 16 moves at cost 24; Dijkstra and A* return 18 moves at cost 22. A* expands 33 cells, compared with 62 for Dijkstra and 66 for BFS. Color encodes expansion order on a shared scale.',
    alt: 'Three heatmaps compare exact BFS, Dijkstra, and A* expansions, returned routes, terrain, and weighted costs on one fixed 10-by-8 board.',
  },
  cycle: {
    file: 'cycle-invariant', title: 'Hamiltonian order in space and time', height: 600, evidence: 'Exact construction and replay',
    caption: 'A 60-cell cycle is paired with a time-by-cycle-index occupancy map from eight legal, nongrowing engine transitions. The body remains a contiguous interval. This invariant assumes compatible initial order and fixed terrain.',
    alt: 'A spatial Hamiltonian grid cycle with head and tail markers is paired with an occupancy heatmap showing a ten-cell body interval advancing through nine time states.',
  },
  connectivity: {
    file: 'connectivity-cut', title: 'An articulation point separates reachable space', height: 590, evidence: 'Exact graph calculation',
    caption: 'Removing passage (5, 3) changes one connected free-space component into two. Flood-fill from the same start reaches 64 cells before removal and 35 afterward. This calculation concerns a frozen terrain graph.',
    alt: 'Two colored coordinate grids show an open and closed bottleneck, alongside a bar chart of reachable cells decreasing from 64 to 35.',
  },
  reward: {
    file: 'reward-telescoping', title: 'Potential-based shaping and cancellation', height: 600, evidence: 'Declared analytical example',
    caption: 'With discount 0.90 and explicitly declared potentials, the matrix exposes positive and negative contributions to the discounted shaping return. Interior terms cancel, leaving six from the initial boundary. This is algebra, not measured learning performance.',
    alt: 'A declared potential sequence and a signed contribution heatmap demonstrate telescoping cancellation, with a final shaping sum of six and zero terminal potential.',
  },
  evaluation: {
    file: 'benchmark-results', title: 'The complete static-grid benchmark', height: 745, evidence: 'Measured 24-case results',
    caption: 'All 24 fixed benchmark cases appear in the cost heatmap, including four unsolved instances. Paired search-effort points and the summary use the 20 solved cases. The 72 recorded rows were checked against a fresh run of the current benchmark.',
    alt: 'A 24-case by three-algorithm weighted-cost heatmap, a paired A-star versus Dijkstra expansion scatterplot, and a table summarize the retained benchmark with unsolved cases explicitly marked.',
  },
};

export function scientificPlateKind(slug?: string): ScientificPlateKind {
  if (['bfs', 'astar', 'dijkstra', 'complexity', 'search'].includes(slug || '')) return 'search';
  if (slug === 'hamiltonian-cycles' || slug === 'cycle') return 'cycle';
  if (['flood-fill', 'bottlenecks', 'wall-mode', 'strategy', 'connectivity'].includes(slug || '')) return 'connectivity';
  if (['reward-shaping', 'reinforcement-learning', 'reward'].includes(slug || '')) return 'reward';
  if (['reproducible-evaluation', 'evaluation', 'benchmark'].includes(slug || '')) return 'evaluation';
  return 'state';
}

/** Compact mode intentionally contains no link, figure, or caption: safe inside an existing anchor. */
export default function ScientificPlate({slug, kind, compact = false, className = '', number, showCaption = true}: {
  slug?: string; kind?: ScientificPlateKind; compact?: boolean; className?: string; number?: number | string; showCaption?: boolean;
}) {
  const selected = kind || scientificPlateKind(slug);
  const plate = scientificPlates[selected];
  const fullUrl = `/research/figures/${plate.file}.svg`;
  const thumbnailAlt: Record<ScientificPlateKind, string> = {
    state: 'Ordered snake segments after a legal move into the vacating tail.',
    search: 'A-star expansion heatmap with the measured route through a weighted grid.',
    cycle: 'A Hamiltonian cycle visits every cell, with a contiguous ordered snake body.',
    connectivity: 'Removing one passage separates the left and right grid components.',
    reward: 'Positive and negative potential-shaping contributions cancel in adjacent columns.',
    evaluation: 'Paired A-star and Dijkstra cell expansions for twenty solved benchmark cases.',
  };
  if (compact) return <img className={`scientific-thumb ${className}`} src={`/research/figures/${selected}-thumb.svg`} width={240} height={180} alt={thumbnailAlt[selected]} loading="lazy" />;
  return <figure className={`scientific-plate ${className}`}>
    <a className="scientific-plate-image" href={fullUrl} target="_blank" rel="noreferrer" aria-label={`Open full vector figure: ${plate.title}`}>
      <img src={fullUrl} width={1200} height={plate.height} alt={plate.alt} loading="lazy" style={{display: 'block', width: '100%', height: 'auto'}} />
    </a>
    {showCaption && <figcaption>
      <p><strong>{number !== undefined ? `Figure ${number}. ` : ''}{plate.title}.</strong> {plate.caption}</p>
      <div className="scientific-plate-meta"><span>{plate.evidence}</span><a href={fullUrl} target="_blank" rel="noreferrer">Open SVG</a><a href={fullUrl} download={`${plate.file}.svg`}>Download SVG</a></div>
    </figcaption>}
  </figure>;
}
