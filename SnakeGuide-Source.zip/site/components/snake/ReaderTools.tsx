'use client';
import {useEffect,useRef,useState} from 'react';
import {Icon} from './Icons';
export function ReadingProgress(){const[value,setValue]=useState(0);useEffect(()=>{function update(){const article=document.querySelector('.article-body');if(!article)return;const box=article.getBoundingClientRect();setValue(Math.min(100,Math.max(0,-box.top/(box.height-window.innerHeight)*100)))}window.addEventListener('scroll',update,{passive:true});update();return()=>window.removeEventListener('scroll',update)},[]);return <div className="reading-progress" aria-hidden="true"><span style={{width:`${value}%`}}/></div>}
export function SaveArticle({slug}:{slug:string}){
 const[saved,setSaved]=useState(false),[error,setError]=useState('');
 useEffect(()=>{try{const list=JSON.parse(localStorage.getItem('snakeguide-saved')||'[]');setSaved(Array.isArray(list)&&list.includes(slug))}catch{}},[slug]);
 function toggle(){try{const parsed=JSON.parse(localStorage.getItem('snakeguide-saved')||'[]');const list:string[]=Array.isArray(parsed)?parsed:[];localStorage.setItem('snakeguide-saved',JSON.stringify(saved?list.filter(s=>s!==slug):[...new Set([...list,slug])]));setSaved(!saved);setError('');window.dispatchEvent(new Event('reading-list-changed'))}catch{setError('Browser storage is unavailable. Use your browser’s bookmark command to save this page.')}}
 return <><button className="reader-action" aria-pressed={saved} onClick={toggle}><Icon name={saved?'check':'bookmark'} size={15}/>{saved?'Saved locally':'Save article'}</button>{error&&<span className="reader-status" role="status">{error}</span>}</>
}
export function CodeBlock({code}:{code:string}){
 const[status,setStatus]=useState(''),pre=useRef<HTMLPreElement>(null);
 async function copy(){try{await navigator.clipboard.writeText(code);setStatus('Copied')}catch{if(pre.current){const range=document.createRange();range.selectNodeContents(pre.current);const selection=window.getSelection();selection?.removeAllRanges();selection?.addRange(range)}setStatus('Code selected. Use your browser’s copy command.')}}
 return <div className="code-block"><div><span>PSEUDOCODE</span><button onClick={copy}><Icon name={status==='Copied'?'check':'copy'} size={13}/>{status==='Copied'?'Copied':'Copy'}</button></div><pre ref={pre}><code>{code}</code></pre>{status&&<span role="status">{status}</span>}</div>
}
export function ArticleContents({sections}:{sections:{title:string;id:string}[]}){const[active,setActive]=useState('');useEffect(()=>{const observer=new IntersectionObserver(items=>{const visible=items.filter(i=>i.isIntersecting);if(visible.length)setActive(visible[0].target.id)},{rootMargin:'-100px 0px -60% 0px'});sections.forEach(s=>{const el=document.getElementById(s.id);if(el)observer.observe(el)});return()=>observer.disconnect()},[sections]);return <nav aria-label="Table of contents">{sections.map((s,i)=><a key={s.id} href={`#${s.id}`} className={active===s.id?'current':''}><span>{String(i+1).padStart(2,'0')}</span>{s.title}</a>)}<a href="#references"><span>↗</span>References</a></nav>}
