import ScientificPlate, {scientificPlateKind, ScientificPlateKind} from './ScientificPlate';
/** Dedicated single-panel scientific thumbnails remain legible in the note index. */
export default function ResearchTeaser({kind='state',slug=''}:{kind?:string;slug?:string}) {
 const fallback:Record<string,ScientificPlateKind>={state:'state',search:'search',cycle:'cycle',bottleneck:'connectivity',learning:'reward'};
 return <ScientificPlate compact kind={slug?scientificPlateKind(slug):(fallback[kind]||'state')} className="research-teaser"/>;
}
