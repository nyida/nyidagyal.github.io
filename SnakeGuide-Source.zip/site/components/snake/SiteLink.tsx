import type {ComponentPropsWithoutRef} from 'react';

/** Native navigation keeps every destination usable before and after hydration.
 * The deployed Vinext link shim can fail while preparing RSC navigation.
 * This content site does not require intercepted client-side routing.
 */
export default function SiteLink(props: ComponentPropsWithoutRef<'a'>) {
  return <a {...props}/>;
}
