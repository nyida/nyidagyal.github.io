import katex from 'katex';
const math:Record<string,string>={
's = (B, d, f, O, ξ),    B = (b₀, b₁, …, bℓ₋₁)':String.raw`s=(B,d,f,O,\xi),\qquad B=(b_0,b_1,\ldots,b_{\ell-1})`,
'B′ = (q, b₀, …, bℓ₋₂)  without food;    B′ = (q, b₀, …, bℓ₋₁)  with food':String.raw`B'=\begin{cases}(q,b_0,\ldots,b_{\ell-2}) & \text{without food}\\(q,b_0,\ldots,b_{\ell-1}) & \text{with food}\end{cases}`,
'release(bᵢ) = ℓ − i    under no growth and continued legal movement':String.raw`\operatorname{release}(b_i)=\ell-i\quad\text{(no growth)}`,
'Gterrain = G[V ∖ O]    and    Gsnapshot = G[V ∖ (O ∪ Bblocked)]':String.raw`\begin{aligned}G_{\mathrm{terrain}}&=G[V\setminus O]\\G_{\mathrm{snapshot}}&=G[V\setminus(O\cup B_{\mathrm{blocked}})]\end{aligned}`,
'R(s) = |reachable vertices from the head in the chosen snapshot graph|':String.raw`R(s)=\left|\operatorname{Reachable}(\mathrm{head},G_{\mathrm{snapshot}})\right|`,
'node = (ordered body, direction, food, rule state, time if needed)':String.raw`\mathrm{node}=(B,d,f,\mathrm{rule\ state},t)`,
'# bodies ≤ min{N!/(N−ℓ)!, N·4·3^(ℓ−2)}    for ℓ ≥ 2':String.raw`\#\mathrm{bodies}\leq\min\left\{\frac{N!}{(N-\ell)!},\;4N\cdot3^{\ell-2}\right\},\quad\ell\geq2`,
'ξ′ = (1664525·ξ + 1013904223) mod 2³²':String.raw`\xi'=(1664525\xi+1013904223)\bmod 2^{32}`,
'h = min(|Δx|, W−|Δx|) + min(|Δy|, H−|Δy|)':String.raw`h=\min(|\Delta x|,W-|\Delta x|)+\min(|\Delta y|,H-|\Delta y|)`,
'd(v) = d(parent(v)) + 1':String.raw`d(v)=d(\operatorname{parent}(v))+1`,
'f(n) = g(n) + h(n)':String.raw`\underbrace{f(n)}_{\text{priority}}=\underbrace{g(n)}_{\text{cost so far}}+\underbrace{h(n)}_{\text{estimated remainder}}`,
'h(x,y) = |x − x_goal| + |y − y_goal|':String.raw`h(x,y)=|x-x_{\mathrm{goal}}|+|y-y_{\mathrm{goal}}|`,
'cost(P) = Σ cost(v_i, v_(i+1))':String.raw`\operatorname{cost}(P)=\sum_{i=0}^{|P|-2}w(v_i,v_{i+1})`,
'd(v) ← min(d(v), d(u) + w(u,v))':String.raw`d(v)\leftarrow\min\bigl(d(v),d(u)+w(u,v)\bigr)`,
'next(i) = (i + 1) mod N':String.raw`\operatorname{next}(i)=(i+1)\bmod N`,
'y = r + γ(1 − terminal) max_a Q_target(o_next, a)':String.raw`y=r+\gamma(1-\mathrm{terminal})\max_a Q_{\mathrm{target}}(o_{\mathrm{next}},a)`,
'r_shaped(s,a,s′) = r_base(s,a,s′) + γΦ(s′) − Φ(s)':String.raw`r_{\mathrm{shaped}}(s,a,s')=r_{\mathrm{base}}(s,a,s')+\gamma\Phi(s')-\Phi(s)`
};
export default function MathExpression({formula}:{formula:string}){const latex=math[formula];return <div className="equation">{latex?<div dangerouslySetInnerHTML={{__html:katex.renderToString(latex,{displayMode:true,throwOnError:false,output:'htmlAndMathml'})}}/>:<span>{formula}</span>}</div>}
