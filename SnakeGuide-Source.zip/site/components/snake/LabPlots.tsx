'use client';
import {Cell,key} from '@/lib/engine';
import {Trace} from '@/lib/explore';
export function expansionColor(order:number,total=120){return 'hsl(99 48% '+(94-30*Math.min(1,order/total))+'%)';}
export function SearchMiniature({trace,walls,terrain,start,goal,w=12,h=10}:{trace:Trace;walls:Set<string>;terrain:Set<string>;start:Cell;goal:Cell;w?:number;h?:number}){
 const order=new Map(trace.frames.map((f,i)=>[key(f.current),i+1]));
 const at=(p:Cell)=>(p.x*14+15)+','+(p.y*14+15);
 return <svg viewBox={'0 0 '+(w*14+16)+' '+(h*14+16)} aria-hidden="true" className="sgl-miniature">{Array.from({length:w*h},(_,i)=>{const x=i%w,y=Math.floor(i/w),k=x+','+y;return <g key={k}><rect x={x*14+8} y={y*14+8} width="14" height="14" fill={walls.has(k)?'#263d31':order.has(k)?expansionColor(order.get(k)!,w*h):'#f7f8f5'} stroke="#ffffff" strokeWidth=".7"/>{terrain.has(k)&&!walls.has(k)&&<path d={'M'+(x*14+18)+','+(y*14+12)+'l2,-3 2,3Z'} fill="#ae7f2e"/>}</g>;})}<polyline points={trace.path.map(at).join(' ')} stroke="#bc3b32" strokeWidth="1.7" strokeLinejoin="round" fill="none"/><rect x={start.x*14+11} y={start.y*14+11} width="8" height="8" fill="#2d652a" stroke="white" strokeWidth="1"/><rect x={goal.x*14+11} y={goal.y*14+11} width="8" height="8" fill="#dc4034" stroke="white" strokeWidth="1"/></svg>;
}
export function FrontierHistory({trace,step}:{trace:Trace;step:number}){
 const values=[1,...trace.frames.map(f=>new Set(f.frontier.map(key)).size)],max=Math.max(1,...values),w=240,h=62;
 const at=(v:number,i:number)=>(i/(values.length-1)*w)+','+(h-v/max*(h-6));
 const points=values.map(at).join(' '),past=values.slice(0,step+1).map(at).join(' '),cx=step/(values.length-1)*w,cy=h-values[step]/max*(h-6);
 return <div className="sgl-history"><div><span>Frontier size</span><b>{values[step]} <small>nodes</small></b></div><svg viewBox="-1 -2 244 78" role="img" aria-label={'Frontier history across '+trace.frames.length+' expansions. Current frontier: '+values[step]+'.'}><line x1="0" y1={h} x2={w} y2={h} className="history-axis"/><line x1="0" y1="6" x2={w} y2="6" className="history-rule"/><polyline points={points} className="history-future"/><polyline points={past} className="history-past"/><line x1={cx} y1="0" x2={cx} y2={h} className="history-cursor"/><circle cx={cx} cy={cy} r="2.8" className="history-dot"/><text x="0" y="75">0</text><text x={w} y="75" textAnchor="end">{trace.frames.length} expansions</text><text x={w} y="3" textAnchor="end">{max}</text></svg></div>;
}
