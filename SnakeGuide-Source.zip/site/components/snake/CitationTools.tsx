'use client';
import {useEffect,useRef,useState} from 'react';
export function CopyCitation({text,label='BibTeX'}:{text:string;label?:string}){
 const[status,setStatus]=useState(''),pre=useRef<HTMLPreElement>(null);
 function select(){if(!pre.current)return;const range=document.createRange();range.selectNodeContents(pre.current);const selection=window.getSelection();selection?.removeAllRanges();selection?.addRange(range)}
 async function copy(){try{await navigator.clipboard.writeText(text);setStatus('Copied')}catch{select();setStatus('Citation selected. Use your browser’s copy command.')}}
 return <details className="bibtex-details"><summary>{label}</summary><pre ref={pre}>{text}</pre><div className="citation-actions"><button onClick={copy}>{status==='Copied'?'Copied':'Copy citation'}</button><button onClick={()=>{select();setStatus('Citation selected.')}}>Select text</button><span role="status">{status==='Copied'?'':status}</span></div></details>
}
export function DownloadText({text,filename,children,type='text/plain'}:{text:string;filename:string;children:React.ReactNode;type?:string}){
 const[url,setUrl]=useState('');
 useEffect(()=>{const next=URL.createObjectURL(new Blob([text],{type:type+';charset=utf-8'}));setUrl(next);return()=>URL.revokeObjectURL(next)},[text,type]);
 return <a className="text-button" href={url||`data:${type};charset=utf-8,${encodeURIComponent(text)}`} download={filename}>{children}</a>
}
