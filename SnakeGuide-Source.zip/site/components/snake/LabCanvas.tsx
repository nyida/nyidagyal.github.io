'use client';
import {useEffect,useId,useMemo,useRef,useState} from 'react';
import {Cell,eq,key} from '@/lib/engine';
import {expansionColor} from './LabPlots';

const U=40,P=28;
const point=(c:Cell)=>[P+c.x*U+U/2,P+c.y*U+U/2];
const points=(cells:Cell[])=>cells.map(c=>point(c).join(',')).join(' ');

function useMovingBody(body:Cell[],duration:number){
 const previous=useRef(body),[display,setDisplay]=useState(body);
 useEffect(()=>{
  const old=previous.current;previous.current=body;
  if(!old.length||body.length<2||!eq(body[1],old[0])||eq(body[0],old[0])||window.matchMedia('(prefers-reduced-motion: reduce)').matches){setDisplay(body);return;}
  let frame=0;const start=performance.now();
  const mix=(a:Cell,b:Cell,t:number)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t});
  const animate=(now:number)=>{const t=Math.min(1,(now-start)/Math.max(40,duration));
   if(t===1){setDisplay(body);return;}
   const tail=body.length>old.length?old.at(-1)!:mix(old.at(-1)!,old.at(-2)!,t);
   setDisplay([mix(old[0],body[0],t),...old.slice(0,-1),tail]);frame=requestAnimationFrame(animate);
  };frame=requestAnimationFrame(animate);return()=>cancelAnimationFrame(frame);
 },[body,duration]);
 return display;
}

type Props={w?:number;h?:number;walls?:Set<string>;terrain?:Set<string>;visited?:Cell[];frontier?:Cell[];current?:Cell|null;route?:Cell[];cycleRoute?:Cell[];body?:Cell[];food?:Cell|null;start?:Cell;goal?:Cell;selected?:Cell|null;distances?:Record<string,number>;indices?:Map<string,number>;showValues?:boolean;duration?:number;running?:boolean;painting?:boolean;onCell?:(cell:Cell,drag:boolean)=>void;onInspect?:(cell:Cell)=>void;label:string;};
const EMPTY:Cell[]=[];
export default function LabCanvas({w=12,h=10,walls=new Set(),terrain=new Set(),visited=EMPTY,frontier=EMPTY,current,route=EMPTY,cycleRoute=EMPTY,body=EMPTY,food,start,goal,selected,distances={},indices,showValues=false,duration=150,running=false,painting=false,onCell,onInspect,label}:Props){
 const uid=useId().replace(/:/g,''),svg=useRef<SVGSVGElement>(null),dragging=useRef(false),last=useRef('');
 const [focus,setFocus]=useState<Cell>({x:0,y:0}),[focused,setFocused]=useState(false);
 const seen=useMemo(()=>new Map(visited.map((p,i)=>[key(p),i+1])),[visited]),open=useMemo(()=>new Set(frontier.map(key)),[frontier]);
 const rendered=useMovingBody(body,duration),head=rendered[0];
 const direction=body.length>1?{x:body[0].x-body[1].x,y:body[0].y-body[1].y}:{x:1,y:0};
 const rotation=Math.atan2(direction.y,direction.x)*180/Math.PI;
 function locate(e:React.PointerEvent<SVGSVGElement>){const node=svg.current;if(!node)return null;const m=node.getScreenCTM();if(!m)return null;const p=new DOMPoint(e.clientX,e.clientY).matrixTransform(m.inverse());const c={x:Math.floor((p.x-P)/U),y:Math.floor((p.y-P)/U)};return c.x>=0&&c.x<w&&c.y>=0&&c.y<h?c:null;}
 const release=()=>{dragging.current=false;last.current='';};
 return <svg ref={svg} className={'sgl-canvas '+(onCell?'editable '+(painting?'painting':''):'')} viewBox={'0 0 '+(w*U+P*2)+' '+(h*U+P*2)} role="img" tabIndex={onCell?0:undefined} aria-label={label+(onCell?' Arrow keys select a cell; Enter or Space applies the active tool.':'')}
  onFocus={()=>setFocused(true)} onBlur={()=>{setFocused(false);release();}}
  onKeyDown={e=>{if(!onCell)return;const d:Record<string,Cell>={ArrowUp:{x:0,y:-1},ArrowDown:{x:0,y:1},ArrowLeft:{x:-1,y:0},ArrowRight:{x:1,y:0}};if(d[e.key]){e.preventDefault();e.stopPropagation();const n={x:Math.max(0,Math.min(w-1,focus.x+d[e.key].x)),y:Math.max(0,Math.min(h-1,focus.y+d[e.key].y))};setFocus(n);onInspect?.(n);}else if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();onCell(focus,false);}}}
  onPointerDown={e=>{if(!onCell||e.button!==0)return;const c=locate(e);if(c){if(painting){e.preventDefault();svg.current?.focus();dragging.current=true;e.currentTarget.setPointerCapture(e.pointerId);}setFocus(c);last.current=key(c);onCell(c,false);onInspect?.(c);}}}
  onPointerMove={e=>{const c=locate(e);if(c){onInspect?.(c);if(dragging.current&&key(c)!==last.current){last.current=key(c);onCell?.(c,true);}}}}
  onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}>
  <title>{label}</title>
  <defs>
   <pattern id={uid+'-wall'} width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="7" stroke="#a7b2a7" strokeWidth=".8"/></pattern>
  </defs>
  {Array.from({length:w},(_,x)=><text key={'x'+x} className="sgl-axis" x={P+x*U+U/2} y="13" textAnchor="middle">{String(x).padStart(2,'0')}</text>)}
  {Array.from({length:h},(_,y)=><text key={'y'+y} className="sgl-axis" x="10" y={P+y*U+U/2+3} textAnchor="middle">{String(y).padStart(2,'0')}</text>)}
  <rect className="sgl-plot-border" x={P-1} y={P-1} width={w*U+2} height={h*U+2}/>
  {Array.from({length:w+1},(_,x)=><line key={'tickx'+x} className="sgl-tick" x1={P+x*U} y1={P-5} x2={P+x*U} y2={P-1}/>)}
  {Array.from({length:h+1},(_,y)=><line key={'ticky'+y} className="sgl-tick" x1={P-5} y1={P+y*U} x2={P-1} y2={P+y*U}/>)}
  {Array.from({length:w*h},(_,i)=>{const c={x:i%w,y:Math.floor(i/w)},k=key(c),wall=walls.has(k),v=distances[k],idx=indices?.get(k),[x,y]=point(c);return <g key={k}>
   <rect className={'sgl-cell'+(wall?' wall':open.has(k)?' frontier':seen.has(k)?' explored':terrain.has(k)?' terrain':'')} x={x-U/2+1} y={y-U/2+1} width={U-2} height={U-2} rx="0" style={!wall&&seen.has(k)?{fill:expansionColor(seen.get(k)!,w*h)}:undefined}/>
   {wall&&<rect x={x-U/2+3} y={y-U/2+3} width={U-6} height={U-6} fill={'url(#'+uid+'-wall)'} rx="0"/>}
   {!wall&&terrain.has(k)&&<path className="sgl-terrain-mark" d={'M'+(x+9)+','+(y-9)+'l3,-5 3,5Z'}/>}
   {!wall&&showValues&&!indices&&v!==undefined&&<text className="sgl-value" x={x} y={y+3} textAnchor="middle">{idx??v}</text>}
  </g>;})}
  {cycleRoute.length>1&&<polyline className={'sgl-cycle-route '+(running?'flow':'')} points={points(cycleRoute)}/>}
  {route.length>1&&<g className="sgl-result-route" key={points(route)}><polyline className="sgl-route-underlay" points={points(route)}/><polyline className="sgl-route" pathLength="1" points={points(route)}/></g>}
  {current&&<rect className={'sgl-current '+(running?'pulsing':'')} x={P+current.x*U+3} y={P+current.y*U+3} width={U-6} height={U-6} rx="0"/>}
  {rendered.length>1&&<><polyline className="sgl-snake-outline" points={points(rendered)}/><polyline className="sgl-snake" points={points(rendered)}/></>}
  {head&&<g transform={'translate('+point(head).join(',')+') rotate('+rotation+')'}><rect x="-14" y="-14" width="28" height="28" rx="4" fill="#24552c"/><path d="M-4,-6L3,0L-4,6" fill="none" stroke="#fff" strokeWidth="2.2"/></g>}
  {indices&&showValues&&Array.from(indices.entries()).map(([k,i])=>{const [x,y]=k.split(',').map(Number),occupied=body.some(c=>c.x===x&&c.y===y);return <text key={'index-'+k} className={'sgl-cycle-index '+(occupied?'on-body':'')} x={P+x*U+U/2} y={P+y*U+U/2+3} textAnchor="middle">{i}</text>;})}
  {start&&<g transform={'translate('+point(start).join(',')+')'}><rect x="-13" y="-13" width="26" height="26" rx="2" fill="#7ed956" stroke="#426f31" strokeWidth="1"/><text className="sgl-pin-label" y="3.5" textAnchor="middle">S</text></g>}
  {(goal||food)&&<g transform={'translate('+point((goal||food)!).join(',')+')'}><rect x="-12" y="-12" width="24" height="24" rx="2" fill="#f04034" stroke="#bd362d" strokeWidth="1"/>{goal?<text className="sgl-pin-label goal" y="3.5" textAnchor="middle">G</text>:<path d="M-6,-6h5" stroke="#ffbeb4" strokeWidth="2"/>}</g>}
  {(focused?focus:selected)&&<rect className="sgl-selected" x={P+(focused?focus:selected)!.x*U} y={P+(focused?focus:selected)!.y*U} width={U} height={U} rx="0"/>}
 </svg>;
}
