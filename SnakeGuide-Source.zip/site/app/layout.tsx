import type { Metadata } from 'next';
import './fonts.css';
import 'katex/dist/katex.min.css';
import './globals.css';
import './academic.css';
import { Header, Footer } from '@/components/snake/Shell';
export const metadata: Metadata = {
 title: {default:'SnakeGuide — Models, Planning & Learning', template:'%s · SnakeGuide'},
 description:'Technical notes, primary literature, and reproducible experiments on Snake state representations, planning algorithms, and reinforcement learning.',
 icons:{icon:{url:'/brand/snakeguide-logo.png',type:'image/png',sizes:'500x500'},shortcut:'/brand/snakeguide-logo.png',apple:'/brand/snakeguide-logo.png'},
};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="en"><body id="top"><a className="skip" href="#main">Skip to content</a><Header/>{children}<Footer/></body></html>}
