import Lab from '@/components/snake/Lab';
import Link from '@/components/snake/SiteLink';
import {ArrowUpRight} from 'lucide-react';
import './lab.css';
export const metadata={title:'Interactive lab'};
export default function Page(){return <main id="main" className="sgl-page"><div className="sgl-page-heading"><div><span className="sgl-overline"><i/>SNAKEGUIDE · COMPUTATIONAL EXPERIMENTS</span><h1>Interactive laboratory</h1><p>Search, topology, and the mechanics of a moving body.</p></div><Link href="/experiments">Methods & benchmarks <ArrowUpRight size={14}/></Link></div><Lab/></main>;}
