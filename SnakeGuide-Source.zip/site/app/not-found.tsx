import Link from '@/components/snake/SiteLink';
export default function NotFound(){return <main id="main" className="page-width empty-state"><span className="eyebrow">404 / OUTSIDE THE GRID</span><h1>This path ends here.</h1><p>The page does not exist in this edition.</p><Link href="/articles" className="button primary">Return to the field guide →</Link></main>}
