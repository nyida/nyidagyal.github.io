import ResearchIndex from '@/components/snake/ResearchIndex';
export const metadata={title:'Technical notes'};
export default function Page(){return <main id="main" className="academic-width notes-page"><div className="academic-page-heading"><h1>Technical notes</h1><p>18 notes on state representation, planning, learning, and experimental design. Each entry includes a full explanation, an interactive figure, and its supporting references.</p></div><ResearchIndex/></main>}
