import Link from '@/components/snake/SiteLink';
import {notFound} from 'next/navigation';
import {articles,getArticle,sources,anchor} from '@/lib/content';
import ArticleFigure from '@/components/snake/ArticleFigures';
import ScientificPlate from '@/components/snake/ScientificPlate';
import {SaveArticle,ReadingProgress,ArticleContents,CodeBlock} from '@/components/snake/ReaderTools';
import {CopyCitation} from '@/components/snake/CitationTools';
import {noteCitation,sourceCitation,paperMetadata} from '@/lib/citations';
import MathExpression from '@/components/snake/MathExpression';
const sectionSources:Record<string,string[][]>={
 astar:[['hart-1968'],['nx-astar'],['nx-astar'],['hart-1968'],[]],
 bfs:[['nx-bfs'],['nx-bfs'],[],[],['gym-env']],
 dijkstra:[['nx-dijkstra'],['nx-dijkstra'],[],[],['nx-dijkstra']],
 'hamiltonian-cycles':[['tapsell-2015'],['itai-1982'],[],['tapsell-2015'],[]],
 'reinforcement-learning':[['gym-env'],['mnih-2013'],['schulman-2017'],['gym-env'],['henderson-2018']],
 'reward-shaping':[[],['ng-1999'],['ng-1999'],[],['gym-env']],
 'reproducible-evaluation':[['battlesnake-ruleset'],['numpy-rng'],['henderson-2018'],['agarwal-2021'],['gym-env']],
 'space-time':[['silver-2005'],[],['gym-env'],[]],
 bottlenecks:[['nx-cut'],[],['nx-cut'],[]],
 'flood-fill':[['nx-bfs'],[],['nx-cut'],[]],
 complexity:[[],[],['itai-1982'],['nx-bfs']],
 'engine-design':[['gym-env'],[],['numpy-rng'],['battlesnake-rules']],
 variants:[['nx-astar'],['battlesnake-rules'],['battlesnake-rules'],['battlesnake-ruleset']],
 'formal-state':[['battlesnake-rules'],['gym-env'],[],[]],
 'tail-movement':[['battlesnake-rules'],[],[],['gym-env']],
 'wall-mode':[['battlesnake-ruleset'],['nx-cut'],['battlesnake-ruleset'],[]],
 strategy:[[],['nx-cut'],['tapsell-2015'],['agarwal-2021']],
 'observation-design':[['gym-env'],[],['mnih-2013'],[],[]]
};
export function generateStaticParams(){return articles.map(a=>({slug:a.slug}));}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}){const a=getArticle((await params).slug);return{title:a?.title||'Note not found',description:a?.description}}
export default async function Page({params}:{params:Promise<{slug:string}>}){
 const a=getArticle((await params).slug);if(!a)notFound();const refs=a.sources.map(id=>sources.find(s=>s.id===id)!);const related=articles.filter(x=>x.slug!==a.slug&&x.category===a.category).slice(0,3);const sections=a.sections.map(s=>({title:s.heading,id:anchor(s.heading)}));
 return <main id="main" className="article-page academic-width"><ReadingProgress/><div className="breadcrumbs"><Link href="/articles">Technical notes</Link><span>/</span><Link href={`/articles?category=${a.category}`}>{a.category}</Link></div>
 <header className="paper-header"><p className="paper-label">Technical note · {a.category} · {a.level}</p><h1>{a.title}</h1><div className="paper-authors"><Link href="/about">SnakeGuide</Link></div><p className="paper-date">November 2026 · {a.minutes} minute read · Explanatory synthesis</p><div className="paper-links"><a href="#figure-overview">vector figure</a><span>/</span><a href="#figure-1">interactive figure</a><span>/</span><a href="#references">references</a><span>/</span><a href="#citation">bibtex</a><span>/</span><a href={`/research/notes/${a.slug}.md`} download>text</a><span>/</span><SaveArticle slug={a.slug}/></div></header>
 <section className="paper-abstract"><h2>Abstract</h2><p>{a.abstract}</p></section><div id="figure-overview" className="article-plate"><ScientificPlate slug={a.slug}/></div><div className="article-layout"><aside className="article-sidebar"><span className="eyebrow">Contents</span><ArticleContents sections={sections}/><div className="prerequisite-note"><p>{a.slug==='formal-state'?'This note defines the reference model.':'Assumes four-neighbor movement unless stated otherwise.'}</p><Link href="/articles/formal-state">State specification</Link><br/><Link href="/experiments">Reproduction protocol</Link></div></aside><article className="article-body"><details className="mobile-contents"><summary>Contents</summary><ArticleContents sections={sections}/></details><p className="key-result"><strong>Key point.</strong> {a.takeaway}</p>
 {a.sections.map((s,i)=><section id={anchor(s.heading)} className="prose-section" key={s.heading}><h2><span>{i+1}.</span><a href={`#${anchor(s.heading)}`}>{s.heading}</a></h2>{s.paragraphs.map((p,j)=><p key={j}>{p}</p>)}{s.formula&&<MathExpression formula={s.formula}/>} {s.code&&<details className="implementation-detail"><summary>Implementation sketch</summary><CodeBlock code={s.code}/></details>}{!!sectionSources[a.slug]?.[i]?.length&&<div className="section-citations">Method references: {sectionSources[a.slug][i].map(id=><a key={id} href={`#ref-${id}`} title={sources.find(x=>x.id===id)?.title}>[{a.sources.indexOf(id)+1}]</a>)}</div>}{i===1&&<div id="figure-1" className="paper-figure"><ArticleFigure slug={a.slug}/></div>}</section>)}
 <section className="article-references" id="references"><h2>References</h2><p className="reference-scope">Source records distinguish established methods from this note’s examples and derivations.</p>{refs.map((s,i)=><div className="citation" id={`ref-${s.id}`} key={s.id}><span>[{i+1}]</span><div><a href={s.url} target="_blank" rel="noreferrer">{s.title}</a><p>{s.authors}. {paperMetadata[s.id]?.venue||s.type}{s.year?`, ${s.year}`:''}.</p><details className="citation-detail"><summary>Scope and connection</summary><p>{s.claim}</p><p>{s.caution}</p><Link href={`/references#${s.id}`}>Full reference record</Link></details><CopyCitation text={sourceCitation(s)}/></div></div>)}</section>
 <section className="note-citation" id="citation"><h2>Cite this technical note</h2><p>This citation identifies the explanatory note, not a peer-reviewed publication.</p><CopyCitation text={noteCitation(a)} label="Show BibTeX"/></section><section className="related-notes"><h2>Related notes</h2><ul>{related.map(x=><li key={x.slug}><Link href={`/articles/${x.slug}`}>{x.title}</Link></li>)}</ul></section></article></div></main>
}
