import assert from 'node:assert/strict';
import {cycle,key,move} from '../lib/engine';
import {cycleGame,cycleAction} from '../lib/lab-controller';

const route=cycle(12,10),indices=new Map(route.map((cell,i)=>[key(cell),i]));
for(const seed of [0,42,4294967295]){
 let state=cycleGame(seed);const actions=[];
 while(state.status==='playing'&&state.steps<120*120){
  const action=cycleAction(state,route,indices);actions.push(action);
  assert.equal(Math.abs(action.x)+Math.abs(action.y),1);
  state=move(state,action);
  assert.equal(new Set(state.body.map(key)).size,state.body.length);
 }
 assert.equal(state.status,'won','Cycle controller must fill the board without collision.');
 assert.equal(state.body.length,120);assert.equal(state.score,117);
 const replay=actions.reduce((game,action)=>move(game,action),cycleGame(seed));
 assert.deepEqual(replay,state,'Exported seed and actions must reproduce the snapshot.');
 console.log('PASS: seed '+seed+' fills all 120 cells in '+state.steps+' ticks; exact action replay matches.');
}
