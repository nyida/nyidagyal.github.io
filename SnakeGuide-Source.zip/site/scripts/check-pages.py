"""Validate the actual static export, including every article and local asset."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
import json
root=Path(__file__).resolve().parent.parent/'out'
class Document(HTMLParser):
 def __init__(self,text):
  super().__init__();self.urls=[];self.ids=set();self.feed(text)
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.add(a['id'])
  for name in ('href','src'):
   if name in a:self.urls.append(a[name])
cache={};errors=[];checked=0
for page in root.rglob('*.html'):
 doc=Document(page.read_text());cache[page]=doc
 for url in doc.urls:
  parts=urlsplit(url)
  if parts.scheme or parts.netloc:continue
  target=(root/unquote(parts.path).lstrip('/')) if parts.path.startswith('/') else page.parent/unquote(parts.path)
  if not parts.path:target=page
  if target.is_dir():target=target/'index.html'
  if not target.exists():errors.append(f'{page.relative_to(root)}: missing {url}');continue
  checked+=1
  if parts.fragment and target.suffix=='.html':
   other=cache.setdefault(target,Document(target.read_text()))
   if unquote(parts.fragment) not in other.ids:errors.append(f'{page.relative_to(root)}: missing anchor {url}')
 assert '/api/benchmark-export' not in page.read_text(), 'A static page cannot depend on the former export API.'
assert (root/'CNAME').read_text().strip()=='snakeguide.org'
assert (root/'.nojekyll').exists()
assert 'Provenance' not in (root/'about/index.html').read_text()
for name in ['index.html','about/index.html']:
 assert 'https://www.speedrun.com/users/nyidagyal' in (root/name).read_text()
assert len(list((root/'articles').glob('*/index.html')))==18
if errors:raise AssertionError('\n'.join(errors))
print(f'PASS: all 18 notes exported; {checked} local links/assets resolve; section anchors, profile links, domain, and static downloads validated.')
