"""Exercise the downloadable reproduction bundle, including CSV coordinates."""
import csv
import io
import json
from pathlib import Path
import subprocess
import tempfile
import zipfile

root = Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory() as directory:
    with zipfile.ZipFile(root / 'public/research/search-experiment-source.zip') as bundle:
        bundle.extractall(directory)
    package = Path(directory) / 'snakeguide-search-experiment'
    subprocess.run(['node', 'verify.cjs'], cwd=package, check=True)
    output = subprocess.check_output(['node', '-e', "const b=require('./lib/benchmark.js');const rows=b.runBenchmark(b.defaultConfig);process.stdout.write(JSON.stringify({rows,csv:b.resultsCsv(rows)}))"], cwd=package, text=True)
    exported = json.loads(output)
    records = list(csv.DictReader(io.StringIO(exported['csv'])))
    assert len(records) == len(exported['rows']) == 72
    for actual, expected in zip(records, exported['rows']):
        assert None not in actual and len(actual) == 12
        assert actual['walls'] == ';'.join(expected['walls'])
        assert actual['terrain'] == ';'.join(expected['terrain'])
        assert actual['algorithm'] == expected['algorithm']
        assert actual['seed'] == str(expected['seed'])
    assert (package / 'typescript/benchmark.ts').read_bytes() == (root / 'lib/benchmark.ts').read_bytes()
print('PASS: downloadable source matches current protocol; all 72 CSV records preserve 12 columns and exact coordinates.')
