import {readdir,readFile,writeFile,cp,rm} from 'node:fs/promises';
import {resolve,relative,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const site=resolve(dirname(fileURLToPath(import.meta.url)),'..'),root=resolve(site,'..'),out=resolve(site,'out');
const walk=async p=>(await Promise.all((await readdir(p,{withFileTypes:true})).map(async e=>e.isDirectory()?walk(resolve(p,e.name)):[relative(out,resolve(p,e.name))]))).flat();
const current=await walk(out),manifest=resolve(root,'.pages-files.json');
let previous=[];try{previous=JSON.parse(await readFile(manifest,'utf8'))}catch{}
for(const path of [...previous,...current]){if(path.startsWith('site/')||path.startsWith('..')||path.startsWith('/')||path.includes('\\'))throw new Error('Unsafe output path: '+path)}
for(const path of previous)if(!current.includes(path))await rm(resolve(root,path),{force:true});
await cp(out,root,{recursive:true});
await writeFile(manifest,JSON.stringify(current.sort(),null,2)+'\n');
console.log('Published '+current.length+' static files into the repository root.');
