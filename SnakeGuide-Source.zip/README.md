# SnakeGuide

Research notes, primary-source references, reproducible experiments, and an interactive Snake laboratory at https://snakeguide.org.

## Edit and build

The editable Next.js/React/TypeScript source is in `site/`. The repository root contains the generated static GitHub Pages website. No runtime server, API key, or ChatGPT account is needed.

```sh
cd site
npm ci
npm run check:lab
npm run check:exports
npm run pages
```

Commit the edited source and regenerated root files together. GitHub Pages continues to publish from `main` at the repository root. `CNAME` retains `snakeguide.org`; `.nojekyll` allows Next.js assets beginning with underscores. The sync script removes only obsolete files previously listed in `.pages-files.json`. Original historical images remain intact.

## Included

- 18 technical notes with mathematical explanations, interactive figures, source citations, and downloadable text.
- Searchable literature and note indexes, browser-local bookmarks, BibTeX, and six scientific SVG plates.
- A 16 × 9 weighted search laboratory with A*, Dijkstra, BFS, editable cells, expansion timeline, frontier history, and matched-input comparisons.
- Hamiltonian traversal and a deterministic 12 × 10 Snake simulator with manual/cycle control and replay exports.
- Seeded static-grid experiments with browser-generated CSV/JSON exports. Exported records use the last completed experiment, not unapplied settings.
- The supplied green/red logo, Speedrun profile links, responsive layouts, and reduced-motion support.

## Validation

The production export renders every route to HTML, including every note. Controller checks fill all 120 cells for three seeds and reproduce action replays exactly. The downloadable experiment source is checked against an independent Bellman-Ford solver on 160 cases, and CSV round trips preserve coordinate lists and all 12 fields. Browser checks cover navigation, hydrated lab controls, experiment reruns, downloads, and source citations.
