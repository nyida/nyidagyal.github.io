import {Cell,eq,key,neighbors} from './engine';
export type Algorithm='BFS'|'Dijkstra'|'A*';
export type SearchFrame={current:Cell;frontier:Cell[];visited:Cell[];distance:Record<string,number>;parent:Record<string,Cell>};
export type Trace={frames:SearchFrame[];path:Cell[];cost:number|null;steps:number|null};
export function traceSearch(w:number,h:number,start:Cell,goal:Cell,walls:Set<string>,algorithm:Algorithm,terrain:Set<string>=new Set()):Trace{
 const queue=[start],distance:Record<string,number>={[key(start)]:0},parent:Record<string,Cell>={},closed=new Set<string>(),visited:Cell[]=[],frames:SearchFrame[]=[];
 const estimate=(p:Cell)=>algorithm==='A*'?Math.abs(p.x-goal.x)+Math.abs(p.y-goal.y):0;
 while(queue.length){if(algorithm!=='BFS')queue.sort((a,b)=>(distance[key(a)]+estimate(a))-(distance[key(b)]+estimate(b)));
 const current=queue.shift()!;if(closed.has(key(current)))continue;closed.add(key(current));visited.push(current);
 if(eq(current,goal)){frames.push({current,frontier:[...queue],visited:[...visited],distance:{...distance},parent:{...parent}});const path=[current];while(!eq(path[0],start))path.unshift(parent[key(path[0])]);return{frames,path,steps:path.length-1,cost:path.slice(1).reduce((s,p)=>s+(terrain.has(key(p))?5:1),0)}}
 for(const n of neighbors(current,w,h)){if(walls.has(key(n))||closed.has(key(n)))continue;const weight=algorithm==='BFS'?1:terrain.has(key(n))?5:1,score=distance[key(current)]+weight;if(score<(distance[key(n)]??Infinity)){distance[key(n)]=score;parent[key(n)]=current;queue.push(n)}}
 frames.push({current,frontier:[...new Map(queue.map(p=>[key(p),p])).values()],visited:[...visited],distance:{...distance},parent:{...parent}});
 }return{frames,path:[],steps:null,cost:null};
}
export const connected=(w:number,h:number,start:Cell,walls:Set<string>)=>{const q=[start],seen=new Set([key(start)]);for(const p of q)for(const n of neighbors(p,w,h))if(!walls.has(key(n))&&!seen.has(key(n))){seen.add(key(n));q.push(n)}return q};
export const searchFixture={w:10,h:8,start:{x:1,y:5},goal:{x:8,y:1},walls:new Set(['4,0','4,1','4,2','4,3','4,4','4,6','4,7','7,3','8,3','9,3'])};
