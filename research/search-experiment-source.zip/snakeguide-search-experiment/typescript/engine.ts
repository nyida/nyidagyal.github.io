export type Cell={x:number;y:number};
export type SearchResult={path:Cell[];visited:Cell[];cost:number|null};
export const key=(p:Cell)=>`${p.x},${p.y}`;
export const eq=(a:Cell,b:Cell)=>a.x===b.x&&a.y===b.y;
export const inside=(p:Cell,w:number,h:number)=>p.x>=0&&p.y>=0&&p.x<w&&p.y<h;
export const neighbors=(p:Cell,w:number,h:number)=>[{x:p.x+1,y:p.y},{x:p.x,y:p.y+1},{x:p.x-1,y:p.y},{x:p.x,y:p.y-1}].filter(q=>inside(q,w,h));
export function search(w:number,h:number,start:Cell,goal:Cell,walls:Set<string>,algorithm='BFS'):SearchResult{
 const frontier=[start], seen=new Set<string>(), dist=new Map([[key(start),0]]),prev=new Map<string,Cell>(),visited:Cell[]=[];
 const heuristic=(p:Cell)=>algorithm==='A*'?Math.abs(p.x-goal.x)+Math.abs(p.y-goal.y):0;
 while(frontier.length){if(algorithm!=='BFS')frontier.sort((a,b)=>(dist.get(key(a))!+heuristic(a))-(dist.get(key(b))!+heuristic(b)));
 const p=frontier.shift()!; if(seen.has(key(p)))continue;seen.add(key(p));visited.push(p);
 if(eq(p,goal)){const path=[p];while(!eq(path[0],start))path.unshift(prev.get(key(path[0]))!);return {path,visited,cost:dist.get(key(p))!};}
 for(const q of neighbors(p,w,h)){if(walls.has(key(q))||seen.has(key(q)))continue;const d=dist.get(key(p))!+1;if(d<(dist.get(key(q))??Infinity)){dist.set(key(q),d);prev.set(key(q),p);frontier.push(q);}}
 }return {path:[],visited,cost:null};
}
export function cycle(w:number,h:number):Cell[]{if(w<2||h<2||h%2!==0)throw new Error('Cycle construction requires even height and both dimensions ≥ 2');const c:Cell[]=[{x:0,y:0}];for(let y=0;y<h;y++){if(y%2===0)for(let x=1;x<w;x++)c.push({x,y});else for(let x=w-1;x>=1;x--)c.push({x,y});}for(let y=h-1;y>=1;y--)c.push({x:0,y});return c;}
export type Game={body:Cell[];food:Cell|null;dir:Cell;seed:number;steps:number;score:number;status:'playing'|'collision'|'won'};
function random(seed:number){return (Math.imul(seed,1664525)+1013904223)>>>0;}
export function foodFor(body:Cell[],w:number,h:number,seed:number){const occupied=new Set(body.map(key)),free:Cell[]=[];for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(!occupied.has(`${x},${y}`))free.push({x,y});const next=random(seed);return {food:free.length?free[next%free.length]:null,seed:next};}
export function initialGame(w=12,h=10,seed=42):Game{const body=[{x:3,y:4},{x:2,y:4},{x:1,y:4}];return {body,...foodFor(body,w,h,seed),dir:{x:1,y:0},steps:0,score:0,status:'playing'};}
export function move(g:Game,dir:Cell,w=12,h=10):Game{if(g.status!=='playing')return g;if(g.body.length>1&&dir.x===-g.dir.x&&dir.y===-g.dir.y)dir=g.dir;const head={x:g.body[0].x+dir.x,y:g.body[0].y+dir.y},grow=g.food!==null&&eq(head,g.food);const blocked=grow?g.body:g.body.slice(0,-1);if(!inside(head,w,h)||blocked.some(p=>eq(p,head)))return {...g,status:'collision',steps:g.steps+1};const body=[head,...g.body];if(!grow)body.pop();const next=grow?foodFor(body,w,h,g.seed):{food:g.food,seed:g.seed};return {...g,body,...next,dir,steps:g.steps+1,score:g.score+(grow?1:0),status:next.food===null?'won':'playing'};}
export const defaultWalls=()=>new Set(['5,0','5,1','5,2','5,3','5,4','5,5','5,7','5,8','5,9','8,3','9,3','10,3','11,3','8,4','8,5','8,6']);
