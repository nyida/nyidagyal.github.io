SnakeGuide static-grid-v1 experiment

Run with Node.js 18 or later; no package installation is required.

  node run.cjs
  node verify.cjs

Optional arguments: node run.cjs INITIAL_SEED CASE_COUNT [unit]
Example: node run.cjs 2026 24 unit
Default: seeds 2026..2049, 24 boards, weighted terrain.

run.cjs writes results.csv and results.json, including complete board inputs.
reference-results.json contains the default run shown on the website.
lib/ contains CommonJS JavaScript compiled from typescript/ using TypeScript
with target ES2022, module commonjs, and skipLibCheck. The compiler is only
needed to modify/recompile the TypeScript sources, not to reproduce a run.

Protocol: 10 x 8, four neighbors ordered right/down/left/up, start (0,0),
goal (9,7), solid boundaries. Row-major generation excludes both endpoints.
Each non-endpoint consumes one random obstacle draw (threshold 0.15).
Free cells consume a second terrain draw (threshold 0.25), even in unit mode.
LCG state updates with Math.imul(1664525,state)+1013904223 modulo 2^32.
Random output is state / 2^32. Case i uses initial seed + i modulo 2^32.
Terrain costs 5 to enter in weighted mode; all other entering costs are 1.
BFS minimizes moves but reports weighted cost. Dijkstra and A* minimize
weighted cost. A* uses Manhattan distance. Array sorting is stable; ties
retain insertion order. Goal expansion is included in the expansion count.

verify.cjs independently checks shortest costs with Bellman-Ford and checks
BFS move lengths on 160 generated grids. Fixed-seed reproduction is also
checked. These are correctness checks on a finite suite, not a proof.

This is static graph search, not a Snake policy or a trained-model benchmark.
Runtime is not measured. Reported means exclude unreachable boards, which
are retained in per-case data. The explicit generator is educational and
not a claim of representativeness of gameplay.

Prepared for SnakeGuide, November 2026.
