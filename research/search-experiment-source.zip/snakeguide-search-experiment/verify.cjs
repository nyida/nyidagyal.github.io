const assert=require('node:assert/strict');
const {makeCase,runBenchmark,defaultConfig}=require('./lib/benchmark.js');
const {traceSearch}=require('./lib/explore.js');
// Independent Bellman-Ford oracle over directed, entering-cost edges.
function oracle(walls,terrain,unit=false){
 const distance=Array(80).fill(Infinity);distance[0]=0;
 for(let pass=0;pass<79;pass++){let changed=false;
  for(let u=0;u<80;u++){if(!Number.isFinite(distance[u]))continue;const x=u%10,y=Math.floor(u/10);
   for(const [dx,dy] of [[0,-1],[-1,0],[0,1],[1,0]]){const xx=x+dx,yy=y+dy;if(xx<0||xx>=10||yy<0||yy>=8)continue;const k=xx+','+yy;if(walls.has(k))continue;const v=yy*10+xx,cost=unit?1:terrain.has(k)?5:1;if(distance[u]+cost<distance[v]){distance[v]=distance[u]+cost;changed=true}}
  }if(!changed)break;
 }return Number.isFinite(distance[79])?distance[79]:null;
}
for(const weighted of [false,true])for(let seed=0;seed<80;seed++){
 const {walls,terrain}=makeCase(seed,weighted),minimum=oracle(walls,terrain);
 for(const algorithm of ['Dijkstra','A*']){const t=traceSearch(10,8,{x:0,y:0},{x:9,y:7},walls,algorithm,terrain);assert.equal(t.cost,minimum);}
 const bfs=traceSearch(10,8,{x:0,y:0},{x:9,y:7},walls,'BFS',terrain);assert.equal(bfs.steps,oracle(walls,terrain,true));
}
assert.deepEqual(runBenchmark(defaultConfig),require('./reference-results.json'));
console.log('PASS: 160 generated grids checked against Bellman-Ford; BFS shortest-move checks pass; reference data reproduced exactly.');
